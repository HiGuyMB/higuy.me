jpg and mcs go in platinum/data/missions_pq/custom
dif goes in platinum/data/interiors_pq/custom

Good luck with the path, Matan has a video if you get stuck.