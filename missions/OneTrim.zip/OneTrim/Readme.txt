png, prev, and mis go in platinum/data/missions/custom
dif goes in platinum/data/interiors_pq/custom