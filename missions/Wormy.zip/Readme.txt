Mission and image go in ~/data/multiplayer/hunt/custom/
Entire higuycomp folder (sorry, CLA team) goes in ~/data/multiplayer/interiors/custom/

Note: This is a multiplayer map, works best with 6-8 players.
If you can't figure out how to play, watch this: https://www.youtube.com/watch?v=mCO1HsOcXM4